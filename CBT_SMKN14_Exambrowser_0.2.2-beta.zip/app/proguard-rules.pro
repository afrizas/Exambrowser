# Tidak ada aturan khusus; minify dimatikan pada versi beta ini.
