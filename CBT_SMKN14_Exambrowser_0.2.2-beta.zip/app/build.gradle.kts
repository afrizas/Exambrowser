plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

// Membaca konfigurasi dari gradle.properties (atau -Pnama=nilai di perintah build).
fun cfg(name: String, default: String): String =
    (project.findProperty(name) as String?) ?: default

// Keystore untuk APK release (opsional). Diisi lewat variabel lingkungan,
// misalnya dari GitHub Secrets. Bila tidak ada, hanya APK debug yang dibuat.
val releaseKeystorePath: String? = System.getenv("CBT_KEYSTORE_FILE")

android {
    namespace = "id.sch.smkn14kabupatentangerang.cbtbeta"
    compileSdk = 35

    defaultConfig {
        applicationId = "id.sch.smkn14kabupatentangerang.cbtbeta"
        minSdk = 23
        targetSdk = 34
        versionCode = 22
        versionName = "0.2.2-beta"

        buildConfigField("String", "PORTAL_URL", "\"${cfg("cbt.portalUrl", "https://cbt.smkn14kabupatentangerang.sch.id/")}\"")
        buildConfigField("String", "APP_HEADER_NAME", "\"${cfg("cbt.appHeaderName", "X-CBT-SMKN14-App")}\"")
        buildConfigField("String", "APP_HEADER_VALUE", "\"${cfg("cbt.appHeaderValue", "SMKN14-Verified")}\"")
        buildConfigField("String", "APP_UA_TOKEN", "\"${cfg("cbt.appUaToken", "CBT-SMKN14-Exambro/0.2.2")}\"")
    }

    buildFeatures {
        buildConfig = true
    }

    signingConfigs {
        if (releaseKeystorePath != null) {
            create("release") {
                storeFile = file(releaseKeystorePath)
                storePassword = System.getenv("CBT_KEYSTORE_PASSWORD")
                keyAlias = System.getenv("CBT_KEY_ALIAS")
                keyPassword = System.getenv("CBT_KEY_PASSWORD")
            }
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
            if (releaseKeystorePath != null) {
                signingConfig = signingConfigs.getByName("release")
            }
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }

    lint {
        abortOnError = false
    }
}
